package MyClasses;

class MyConstants {


    public static final String SITE_KEY ="6Ld1iB4TAAAAAMRFEWGYVFqGVu_z3THeQd16OkMo";

    public static final String SECRET_KEY ="6Ld1iB4TAAAAADZlLIthHSmQYlX5pKyIlQpC11Bv";

}

